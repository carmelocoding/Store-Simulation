#include "defs.h"


void loadStoreData(StoreType *store)
{
  AccountType  *acc;
  CustomerType *cust;
  int currCustId = NEXT_CUST_ID;
  int currAcctId = NEXT_ACCT_ID;

  initCustomer(currCustId++, "Kara", &cust);
  addCustomer(&store->customers, cust);
  initAccount(currAcctId++, SAVINGS, cust, 10.0f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);
  initAccount(currAcctId++, SAVINGS, cust, 50.0f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);
  initAccount(currAcctId++, CHEQUING, cust, 280.42f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);

  initCustomer(currCustId++, "Lee", &cust);
  addCustomer(&store->customers, cust);
  initAccount(currAcctId++, SAVINGS, cust, 4598.0f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);
  initAccount(currAcctId++, CHEQUING, cust, 2344.98f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);

  initCustomer(currCustId++, "Laura", &cust);
  addCustomer(&store->customers, cust);
  initAccount(currAcctId++, SAVINGS, cust, 8771.14f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);
  initAccount(currAcctId++, CHEQUING, cust, 6832.55f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);
  initAccount(currAcctId++, CHEQUING, cust, 459.0f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);

  initCustomer(currCustId++, "William", &cust);
  addCustomer(&store->customers, cust);
  initAccount(currAcctId++, CHEQUING, cust, 3455.76f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);

  initCustomer(currCustId++, "Sharon", &cust);
  addCustomer(&store->customers, cust);

  initCustomer(currCustId++, "Karl", &cust);
  addCustomer(&store->customers, cust);
  initAccount(currAcctId++, SAVINGS, cust, 1256.80f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);
  initAccount(currAcctId++, CHEQUING, cust, 3207.82f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);

  initCustomer(currCustId++, "Gaius", &cust);
  addCustomer(&store->customers, cust);
  initAccount(currAcctId++, CHEQUING, cust, 10988.44f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);
  initAccount(currAcctId++, CHEQUING, cust, 45.87f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);

  initCustomer(currCustId++, "Six", &cust);
  addCustomer(&store->customers, cust);

  initCustomer(currCustId++, "Saul", &cust);
  addCustomer(&store->customers, cust);

  initCustomer(currCustId++, "Ellen", &cust);
  addCustomer(&store->customers, cust);

  initCustomer(currCustId++, "Sam", &cust);
  addCustomer(&store->customers, cust);

  initCustomer(currCustId++, "Dee", &cust);
  addCustomer(&store->customers, cust);
  initAccount(currAcctId++, SAVINGS, cust, 200.0f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);
  initAccount(currAcctId++, SAVINGS, cust, 1498.6f, &acc);
  addAccount(&store->accounts, acc);
  addAccount(cust->accounts, acc);

  initAccount(currAcctId++, CHEQUING, NULL, 150.0f, &acc);
  addAccount(&store->accounts, acc);

  initAccount(currAcctId++, OTHER, NULL, 580.0f, &acc);
  addAccount(&store->accounts, acc);
}

/*
  Function:  initstore
  Purpose: initializes account list and customer array for the store
  out: storeType *b
  return: void
*/
void initStore(StoreType *b){
  initAcctList(&b->accounts);
  initCustArray(&b->customers);
}

/*
  Function:  cleanupStore
  Purpose: frees all allocated parts of the store
  in/out: storeType *store
  return: void
*/
void cleanupStore(StoreType *b){
  cleanupAcctData(&b->accounts);
  cleanupAcctList(&b->accounts);
  cleanupCustArray(&b->customers);
}


