#include "defs.h"

int main()
{
  StoreType newStore;
  initStore(&newStore);
  loadStoreData(&newStore);
  int select;

  do{

      printMenu(&select);

      if(select == 1){
        printCustomers(&newStore.customers);

      }

       if(select == 2){
         printAccounts(&newStore.accounts, C_TRUE);
        
       }
       
        if(select == 3){
          printByBalance(&newStore.accounts, C_TRUE);
        }

  }while(select != 0);
  
  cleanupStore(&newStore);
  return(0);
}



void printMenu(int *choice)
{
  int c = -1;
  int numOptions = 3;

  printf("\nMAIN MENU\n");
  printf("  (1) Print customers\n");
  printf("  (2) Print accounts\n");
  printf("  (3) Print accounts by balance\n");
  printf("  (0) Exit\n\n");

  printf("Please enter your selection: ");
  scanf("%d", &c);

  if (c == 0) {
    *choice = c;
    return;
  }

  while (c < 0 || c > numOptions) {
    printf("Please enter your selection: ");
    scanf("%d", &c);
  }

  *choice = c;
}

