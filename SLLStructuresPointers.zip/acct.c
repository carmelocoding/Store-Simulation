#include "defs.h"

/*
  Function:  initAcctList
  Purpose: initalizes an acctlist by setting the lists head and tail to null
  out: AcctListType *list
  return: void
*/
void initAcctList(AcctListType *list){
    list->head = NULL;
    list->tail = NULL;
}

/*
  Function:  initAccount
  Purpose: initalizes an account by giving all its parameters values
  in: int n, AcctEnumType at, CustomerType *c, float b, AccountType **acct
  return: void
*/
void initAccount(int n, AcctEnumType at, CustomerType *c, float b, AccountType **acct){

    (*acct) = malloc(sizeof(AccountType));
    (*acct)->acctNum = n;
    (*acct)->acctType = at;
    (*acct)->balance = b;
    (*acct)->cust = c;
}

/*
  Function:  addAccount
  Purpose: adds an account to the back of an acctlisttype linked list
  in: AccountType *acct
  in/out: AcctListType *list
  return: void
*/
void addAccount(AcctListType *list, AccountType *acct){

  NodeType *newNode;
  newNode = malloc(sizeof(NodeType));
  newNode->data = acct;
  newNode->next = NULL;

  if(list->head == NULL){
      list->head = newNode;
  }
  else{
      list->tail->next = newNode;
  }
    list->tail = newNode;

}

/*
  Function:  addAccountByBalance
  Purpose: adds an account to a acctlist list based  on its balance (descending order) by comparing the current acct balance and the other acct's balance
  in: AccountType *acct
  in/out: AcctListType *list
  return: void
*/
void addAccountByBalance(AcctListType *list, AccountType *acct){

    NodeType *prev;
    NodeType *curr;
    NodeType *newNode;

    newNode = malloc(sizeof(NodeType));
    newNode->data = acct;
    newNode->next = NULL;
    prev = NULL;
    curr = list->head;

    if(curr == NULL){
        list->head = newNode;
        list->tail = newNode;
    }
    else{
        while(newNode->data->balance < curr->data->balance && curr != list->tail->next){
            prev = curr;
            curr = curr->next;
        }
        if(prev == NULL){
            list->head = newNode;
            list->head->next = curr;
        }
        else if(curr == NULL){
             list->tail->next = curr;
             list->tail = curr;
             curr->next = NULL;
        }
        else{
            prev->next = newNode;
            newNode->next = curr;
        }
    }
}

/*
  Function:  printAccount
  Purpose: prints out all details of a account, checking which strings should be printed based on enumarated data and null values
  in: AccountType *acct
  return: void
*/
void printAccount(AccountType *acct){

    char acctKind[MAX_STR] = {0};
    char acctName[MAX_STR];

    if(acct->acctType == CHEQUING){
        strcpy(acctKind, "Chequing");
    }
    else if(acct->acctType == SAVINGS){
        strcpy( acctKind,"Savings");
    }
    else if (acct->acctType == OTHER){
        strcpy( acctKind,"Other");
    }
    else{
        strcpy(acctKind,"Unknown" );
    }

    if(acct->cust == NULL){
        strcpy(acctName, "Unknown");
    }else{
        strcpy(acctName, acct->cust->name);
    }
    
    printf("Acct Num: %12d   Type: %12s  Owner: %10s   Balance: $ %10.2f\n", acct->acctNum, acctKind, acctName, acct->balance);

}

/*
  Function:  printAccounts
  Purpose: iterates through each account in the acct list and prints each account, along with the tail and head if requested
  in: AcctListType *list, int ends
  return: void
*/
void printAccounts(AcctListType *list, int ends){
    if(list->head == NULL){
        printf("NO ACCOUNTS\n");
    }
    else{
        NodeType *curr;
        curr = list->head;

        while(curr != NULL){
            printAccount(curr->data);
            curr = curr->next;
        }
        if(ends == C_TRUE){
            printf("-- HEAD: ");
            printAccount(list->head->data);
            printf("-- TAIL: ");
            printAccount(list->tail->data);
        } 
    }
}

/*
  Function:  addAccountByBalance
  Purpose: iterates through the acctlist and frees each piece of data in each account
  in/out: AcctListType *list
  return: void
*/
void cleanupAcctData(AcctListType *list){

    NodeType *curr;
    curr = list->head;

    while(curr != NULL){
        free(curr->data);
        curr = curr->next;
    }
}

/*
  Function:  cleanupAcctList
  Purpose: iterates through the acctlist and frees each node,storing it before so it doesnt lose its place
  in/out: AcctListType *list
  return: void
*/
void cleanupAcctList(AcctListType *list){
    NodeType *curr;
    NodeType *temp;
    curr = list->head;

    while(curr != NULL){
        temp = curr->next;
        free(curr);
        curr = temp;
    }
    
}

/*
  Function:  printByBalance
  Purpose: iterates through the acctlist and adds each account by balance to the temp list, then printing and cleaning it
  in/out: AcctListType *list
  in: int ends
  return: void
*/
void printByBalance(AcctListType *orgList, int ends){
    
    AcctListType tempList;
    initAcctList(&tempList);

    NodeType *curr;
    curr = orgList->head;

    while(curr != NULL){
        addAccountByBalance(&tempList, curr->data);
        curr = curr->next;
    }

    printAccounts(&tempList, ends);
    cleanupAcctList(&tempList);
}


