#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define C_TRUE     1
#define C_FALSE    0

#define MAX_ARR  128
#define MAX_STR   32

#define NEXT_CUST_ID    4001
#define NEXT_ACCT_ID  700210

typedef enum { CHEQUING, SAVINGS, OTHER } AcctEnumType;

struct AcctList;

typedef struct {
  int  id;
  char name[MAX_STR];
  struct AcctList *accounts;
} CustomerType;

typedef struct {
  int          acctNum;
  AcctEnumType acctType;
  CustomerType *cust;
  float        balance;
} AccountType;

typedef struct{
  CustomerType *elements[MAX_ARR];
  int size;
}CustArrayType;

typedef struct Node{
  AccountType *data;
  struct Node *next;
}NodeType;

typedef struct AcctList {
  NodeType *head;
  NodeType *tail;
} AcctListType;

typedef struct  {
  AcctListType accounts;
  CustArrayType customers;
} StoreType;


void printMenu(int*);

void loadStoreData(StoreType *store);

void initAcctList(AcctListType *list);
void initAccount(int n, AcctEnumType at, CustomerType *c, float b,
AccountType **acct);
void addAccount(AcctListType *list, AccountType *acct);
void addAccountByBalance(AcctListType *list, AccountType *acct);
void printAccount(AccountType *acct);
void printAccounts(AcctListType *list, int ends);
void cleanupAcctData(AcctListType *list);
void cleanupAcctList(AcctListType *list);
void printByBalance(AcctListType *orgList, int ends);

void initCustArray(CustArrayType *arr);
void initCustomer(int id, char *n, CustomerType **cust);
void addCustomer(CustArrayType *arr, CustomerType *c);
void printCustomers(CustArrayType *arr);
void cleanupCustArray(CustArrayType *arr);
void initStore(StoreType *b);
void cleanupStore(StoreType *b);