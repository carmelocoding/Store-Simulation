#include "defs.h"

/*
  Function:  initCustArray
  Purpose: initializes a customer array to have a size of 0
  in/out: CustArrayType *arr
  return: void
*/
void initCustArray(CustArrayType *arr){
    arr->size = 0;
}

/*
  Function:  initCustomer
  Purpose: initializes a customer and the customers acct list
  out: int id, char *n, CustomerType **cust
  return: void
*/
void initCustomer(int id, char *n, CustomerType **cust){
    (*cust) = malloc(sizeof(CustomerType));
    (*cust)->id = id;
    strcpy((*cust)->name, n);
    (*cust)->accounts = malloc(sizeof(AccountType));
    initAcctList((*cust)->accounts);
}

/*
  Function:  addCustomer
  Purpose: adds a customer to the back of a customer array, checking to see if it full first
  in/out: CustArrayType *arr
  in: CustomerType *c
  return: void
*/
void addCustomer(CustArrayType *arr, CustomerType *c){
    if(arr->size == MAX_ARR){
        printf("\nArray is full, customer could not be added.");
        return;
    }
    arr->elements[arr->size] = c;
    arr->size++;
}

/*
  Function:  printCustomers
  Purpose: prints all customers along with their accounts in a given customer array
  in: CustArrayType *arr
  return: void
*/
void printCustomers(CustArrayType *arr){
    
    for(int i = 0; i < arr->size; i++){
        printf("%-16d %-12s\n", arr->elements[i]->id, arr->elements[i]->name);
        printAccounts(arr->elements[i]->accounts, C_FALSE);       
        printf(" \n");

    }
}

/*
  Function:  cleanupCustArray
  Purpose: frees account nodes of each customer along with the account list itself and frees the customer node too
  in/out: CustArrayType *arr
  in: CustomerType *c
  return: void
*/
void cleanupCustArray(CustArrayType *arr){
    //keep track of pointer before removing it, then set curr to next
    for(int i = 0; i < arr->size; i++){
        //already handled
        cleanupAcctList(arr->elements[i]->accounts);
        free(arr->elements[i]->accounts);
        free(arr->elements[i]);
        
    }

}


